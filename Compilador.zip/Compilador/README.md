
# Compilador &mdash; Trabalho Laborational

## Compilador para a Linguagem C0 

Prentende-se que implementem um compilador básico da *linguagem C0*,
um dialeto da linguagem C para ensino desenvolvido em CMU.  O
compilador deverá ler código fonte C0 e gerar linguagem *assembly*
MIPS.

Consultar a [documentação](docs/trabalho.pdf) para mais informação.

---

Pedro Vasconcelos, 2020.

